
package warenautomat;

import java.util.Date;

import warenautomat.SystemSoftware;


public class Drehteller {
  
  // TODO
  
}
